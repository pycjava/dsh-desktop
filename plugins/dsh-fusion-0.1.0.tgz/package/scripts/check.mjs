// Syntax gate: every JS/MJS file in the package must parse standalone. This is
// the cheap guard against the ecosystem's known failure mode — a plugin file
// that references an unimported symbol only blows up at runtime, inside DSH.

import { readdirSync } from 'node:fs'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'

const ROOTS = ['lib', 'agent-presets', 'scripts', 'test']

function collect(dir, out) {
  let entries
  try {
    entries = readdirSync(dir, { withFileTypes: true })
  } catch {
    return
  }
  for (const entry of entries) {
    if (entry.name === 'node_modules') continue
    const full = join(dir, entry.name)
    if (entry.isDirectory()) collect(full, out)
    else if (/\.(mjs|js)$/.test(entry.name)) out.push(full)
  }
}

const files = []
for (const root of ROOTS) collect(root, files)

let failed = 0
for (const file of files) {
  try {
    execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' })
  } catch (error) {
    failed += 1
    console.error(`✖ ${file}\n${error.stderr}`)
  }
}

console.log(`${files.length - failed}/${files.length} files pass syntax check`)
process.exit(failed === 0 ? 0 : 1)
