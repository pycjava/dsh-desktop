// Live-machine install verifier: run on a machine WITH DSH to confirm the
// fusion deployment is healthy before any evaluation session. Checks:
//   1. preset files present under <dshHome>/.agent-presets/fusion/
//   2. profile patch file parses as a single top-level array (no double
//      top-level value, no duplicate entry ids) — the two startup-fatal shapes
//   3. the fusion bundle row is present in the web profile patch or the
//      profile package.json bundles list (official assembly happened)
// Usage: node scripts/verify-install.mjs [dshHome]   (default: %USERPROFILE%/.dsh)
// Exit 0 = healthy, 1 = problems found (each printed with a fix hint).

import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { fixPatchText } from './fix-patch.mjs'

export function verifyInstall(dshHome) {
  const problems = []
  const presetDir = join(dshHome, '.agent-presets', 'fusion')

  for (const file of ['agent.cordis.yml', 'preset.yml', 'fusion-bootstrap.mjs', 'fusion-core.mjs', 'epoch-promotion.mjs']) {
    if (!existsSync(join(presetDir, file))) {
      problems.push(`missing preset file: ${join(presetDir, file)} — restart DSH once so the host installer deploys it, or run install.ps1`)
    }
  }

  const patchPath = join(dshHome, 'profiles', 'web', 'cordis.patch.yml')
  if (existsSync(patchPath)) {
    const text = readFileSync(patchPath, 'utf8')
    const result = fixPatchText(text)
    if (result.changed) {
      problems.push(`profile patch is startup-fatal (standalone [] above entries: ${result.removedStandaloneList}, duplicate ids: ${result.duplicates}) — run: node scripts/fix-patch.mjs "${patchPath}"`)
    }
  } else {
    problems.push(`no web profile patch at ${patchPath} — run: dsh plugin --profile web add <dsh-fusion checkout>`)
  }

  const profilePkgPath = join(dshHome, 'profiles', 'web', 'package.json')
  let assembled = false
  if (existsSync(profilePkgPath)) {
    try {
      const pkg = JSON.parse(readFileSync(profilePkgPath, 'utf8'))
      assembled = (pkg.dsh?.profile?.bundles ?? []).includes('dsh-fusion') || Object.keys(pkg.dependencies ?? {}).includes('dsh-fusion')
    } catch {
      problems.push(`cannot parse ${profilePkgPath}`)
    }
  }
  if (!assembled && existsSync(patchPath)) {
    try {
      assembled = readFileSync(patchPath, 'utf8').includes('dsh-fusion')
    } catch {
      /* already reported above */
    }
  }
  if (!assembled) problems.push('dsh-fusion not found in web profile bundles or patch — run install.ps1')

  return { ok: problems.length === 0, problems, presetDir }
}

function main() {
  const dshHome = process.argv[2] ?? process.env.DSH_HOME ?? join(homedir(), '.dsh')
  const { ok, problems, presetDir } = verifyInstall(dshHome)
  console.log(`dsh home:   ${dshHome}`)
  console.log(`preset dir: ${presetDir}`)
  if (ok) {
    console.log('healthy: preset deployed, patch clean, bundle assembled')
    console.log('next: restart DSH fully, create a NEW session, select "Fusion (experimental)"')
    return
  }
  for (const problem of problems) console.error(`✖ ${problem}`)
  process.exitCode = 1
}

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main()
}
