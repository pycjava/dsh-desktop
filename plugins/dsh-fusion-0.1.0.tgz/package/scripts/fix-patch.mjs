// Zero-dependency rescue tool for a corrupted profile patch file
// (`~/.dsh/profiles/<p>/cordis.patch.yml`). Two fatal shapes, both fixed here:
//   1. double top-level value — a leftover standalone `[]` line above entries
//      (blind appends produce this; YAML refuses two top-level values)
//   2. duplicate `id:` entries — the loader throws `duplicate loader entry id`
//      at startup, and a plugin cannot self-heal that (chicken-and-egg)
// Usage: node scripts/fix-patch.mjs <path-to-cordis.patch.yml>
// Only rewrites when a fix was applied; always backs up first.

import { copyFileSync, readFileSync, writeFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'

export function fixPatchText(text) {
  const lines = text.split(/\r?\n/)
  const stripped = lines.filter((line, index) => {
    const bare = line.trim()
    // Remove a standalone [] that sits above at least one entry line.
    if (bare === '[]') return !lines.slice(index + 1).some((later) => later.trim().startsWith('- id:'))
    return true
  })

  const blocks = []
  let current = null
  for (const line of stripped) {
    if (line.trim().startsWith('- id:')) {
      if (current !== null) blocks.push(current)
      current = [line]
    } else if (current !== null) {
      current.push(line)
    } else {
      blocks.push([line]) // comments / blank lines before the first entry
    }
  }
  if (current !== null) blocks.push(current)

  const seen = new Set()
  const kept = []
  let duplicates = 0
  for (const block of blocks) {
    const match = /^-\s*id:\s*(\S+)/.exec(block[0].trim())
    if (match === null) {
      kept.push(block)
      continue
    }
    if (seen.has(match[1])) {
      duplicates += 1
      continue // keep the first occurrence, drop later duplicates
    }
    seen.add(match[1])
    kept.push(block)
  }

  const fixedText = kept.map((block) => block.join('\n')).join('\n').replace(/\n{3,}/g, '\n\n').trimEnd() + '\n'
  const changed = fixedText !== text
  return { text: fixedText, changed, removedStandaloneList: lines.length !== stripped.length, duplicates }
}

function main() {
  const target = process.argv[2]
  if (target === undefined) {
    console.error('usage: node scripts/fix-patch.mjs <path-to-cordis.patch.yml>')
    process.exit(2)
  }
  const text = readFileSync(target, 'utf8')
  const result = fixPatchText(text)
  if (!result.changed) {
    console.log(`${target}: already clean (no standalone [], ${result.duplicates} duplicate ids removed? none)`)
    return
  }
  copyFileSync(target, `${target}.bak`)
  writeFileSync(target, result.text)
  console.log(
    `${target}: fixed (standalone [] removed: ${result.removedStandaloneList}, duplicate ids dropped: ${result.duplicates}); backup at ${target}.bak`,
  )
}

if (process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main()
}
