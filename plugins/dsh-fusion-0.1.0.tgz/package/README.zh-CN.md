# dsh-fusion

> DeepSeek Harness 的实验性 agent preset：锚定轮路由、按 epoch 晋升、渐进式工具解锁、Windows Git Bash 执行器与可选预热回放。

[English](README.md)

面向 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）的任务感知锚定预设：首轮任务路由、按 epoch 晋升、渐进式工具解锁、win32 Git Bash 执行器与可选预热回放——融合自五个生态项目（`dsh-anchored-standard`、`dsh-router-standard`、`dsh-gitbash-preset`、`myDshPresets`、`dsh-routing-suite`）的最佳实践。

**状态：M0–M3 已实现。** 设计与研究文档在本仓库中（`PLUGIN-SYNTHESIS.md` 等）；规格说明与工单看板位于 `.scratch/dsh-fusion/`。

面向 DeepSeek Harness **0.1.0-rc.6**（开发者预览版——上游破坏性变更在所难免）。

## 它能做什么

1. **首轮锚定（whoami，默认）** — 当用户第一条真实消息到达时，一条合成身份问题（`你是谁`，可配置）会被排到收件队列中该消息之前；dsh 每轮只消费一条下一轮消息，因此第 1 次请求只有身份问题本身，运行在**空工具面**上，system prompt 只有 persona 段（`You are a helpful software engineer assistant.`）——完全零注入：runtime-context 快照全会话抑制，AGENTS.md/技能目录上下文剥离，插件提示（例如用户审批策略变更通知）延迟到晋升后的第一步。模型的自我介绍回复既是第一条持久化 assistant 消息，也是晋升信号——一份自写的协作者身份，把轨迹锚定成 we 风格。同任务/同模型 A/B：whoami 在 18 个带工具步骤中保持 we 风格、零第一人称标记，并以 18 步完成；schema-pair 锚定结果不稳定（一次运行：30 步中出现 62 个第一人称标记，被中断）。`anchorMode: 'pair'` 则换用零额外调用的配方：真实任务 + 持久 schema 的 `bash` + `str_replace_editor`（anchored-standard #11 Minimal 工具对——各平台字节级一致，win32 上由 Git Bash 支撑 `bash`）。
2. **晋升后任务路由** — 第一条真实用户消息被分类（双语关键词规则，零模型调用）为 `spec`（读优先）、`react`（写优先）或 `weak`；该任务带的核心工具在首个晋升请求（#2 起）加入目录，任务带 persona 替换 persona 段文本——每个任务带 persona 都以完全相同的 Minimal 句开头（system prompt 的首字节在整个会话中不变），尾部是 we 语气的身份声明，且不含“请说明你的选择”之类的元指令（这类指令曾被原样复述并立即把模型重新框成 “Let me …”），整个会话期间 prompt 保持 persona 尺寸（完整 Standard prompt 永不回归：实测恢复它会立即把锚定的 “We need…” 风格翻转回 “Let me”）。weak 会话的近场引导同样等到晋升之后。
3. **按 epoch 晋升** — 第一条持久化 `tool/call` 或 `assistant/message` 晋升会话（一次目录变更）。`compaction/end` 是 epoch 边界：折叠之后会话回到受控期，直到新信号出现。所有阶段状态均由持久事件推导——resume/reload 安全。
4. **渐进式解锁** — 晋升后的目录是最小常驻集 + `dev_tool_search`；重型 Standard 工具一次搜索即可取得，解锁调用从持久日志重放。
5. **win32 Git Bash 后端** — Windows 上通过 Git for Windows 让 `bash` 可用（`<bash> -c <command>`，每条命令新开 shell，受沙箱门控），并以持久工具的 schema 字节注册，使锚定身份成立。
6. **可选预热回放（默认关闭）** — 一个合成预热轮，其模型调用被重放的 chunk 流短路；每个新会话省一次模型调用。
7. **子代理锚定**（默认开启） — 委托出去的 agent 会话走同样的 whoami 锚定轮：任务 prompt（一条 user 类收件消息）之前会被前置身份问题，第 1 轮在空工具面上自我介绍，该回复把子代理晋升到常驻目录。子代理的 persona 永不被替换（子代理自带 persona 是其唯一契约——`dsh-subagent` 的 persona 选项），近场引导不会在子代理内触发，收窄的子代理目录（toolFilter 风格）会软失败为透传。每个子代理多一次模型调用；`anchorSubagents: false` 则让子代理从全量目录预晋升状态开始。

8. **自优化工具**（仅晋升后） — `dev_router_status`、`dev_router_mode`（显式覆盖；进程本地）、`dev_mode_subagent`（在另一 persona 下隔离的单任务调用，会话中途不切换 persona）。

## 安装（需要已安装 DSH）

```powershell
# 从本仓库克隆：
.\install.ps1
# …或直接：
dsh plugin --profile web add <path-to-this-repo>
```

完全重启 DSH，创建**新**会话，选择 **Fusion (experimental)**。不要在会话中途切换预设。

如果部分安装后 DSH 无法启动：`node scripts\fix-patch.mjs %USERPROFILE%\.dsh\profiles\web\cordis.patch.yml`。

## 配置开关（`agent-presets/fusion/agent.cordis.yml`）

| 行 | 开关 | 默认值 | 作用 |
|---|---|---|---|
| fusion-bootstrap | `anchorMode` | `whoami` | 锚定轮：空工具面上的合成身份轮（`pair` = 在真实任务上使用 Minimal 工具对，零额外调用） |
| | `anchorText` | `你是谁` | 身份问题文本（仅 whoami 模式） |
| | `anchorSubagents` | `true` | 委托会话走同样的锚定轮；晋升后子代理保留常驻目录但绝不替换 persona（子代理 persona 可能是其唯一契约）。每个子代理多一次模型调用 |
| | `promoteOn` | `either` | 晋升信号：`tool-call` \| `assistant-message` \| `either`（whoami 模式将 tool-call 强制为 either——0 工具轮不可能产生 tool/call） |
| | `bootstrapTools` | `[bash, pwsh, str_replace_editor]` | Minimal 工具对成员——按 `shellPriority` 选持久 schema shell + `str_replace_editor`；`pwsh` 不会进入锚定轮，但 win32 上晋升后保持常驻 |
| | `residentTools` | `[modlens_read_image]` | 晋升后始终常驻、但不属于 Minimal 锚定工具对的工具；绝不会出现在锚定轮 |
| | `shellPriority` | `[bash, pwsh]` | 哪个 shell 赢得锚定轮 |
| | `suppressedContextSources` | `[agent-instructions, skill-catalog]` | 晋升前注入剥离（`[]` 关闭） |
| | `deferPluginNotes` | `true` | 晋升前延迟插件注入的用户消息（如用户审批策略提示）；在晋升后第一步重新投递 |
| | `discoveryTools` | `[dev_tool_search]` | 晋升后常驻的发现工具 |
| | `compactionTools` | 见 yml | 压缩后的工具集 |
| | `routing` / `nearGuidance` | `true` | 晋升后任务带 persona/核心工具 / weak 会话近场引导 |
| warmup-replay | `enabled` | `false` | 预热轮 + 首次调用重放否决 |
| | `message` / `replayFile` | 见 yml | 预热 prompt / 重放数据（内置文件是 SYNTHETIC 占位——生产环境请录制真实会话） |
| gitbash-executor | `shellPath` | 自动探测 | 显式 Git Bash 路径（否则 `GIT_BASH` → 安装目录 → PATH） |
| | `timeoutMs` / `maxOutputBytes` / `graceMs` | `120000` / `64000` / `3000` | 命令超时与输出窗口 |

Host 安装器（bundle 行上的 `dsh` patch 配置）：`dshHome`、`presetId`、`force`（覆盖过期的预设文件）、`presetSourceDir`（测试接缝）。

## 兼容性

| DSH | 状态 |
|---|---|
| 0.1.0-rc.6 | 目标版本。基线组合快照取自 rc.6 Standard 预设。 |
| 0.1.0-rc.5 | 基本兼容；**请求预算注意事项**：rc.6 预构建 profile 可能覆盖建议的首轮 maxTokens 上限（no-op）——dsh-fusion 默认不设上限，因此不受影响。任何升级后请核对 `request/header`。 |

已知上游脆弱点（每次 rc 升级都会核对）：waterfall 监听器顺序（`prepend` 契约）、`agent/request` maxTokens 语义、patch 方言。

## 安全说明

- Git Bash 执行器**绝不绕过沙箱**：它只在 `danger-full-access` 下运行；受限模式会收到一次性提权消息（附理由），由用户批准或拒绝。
- `danger-full-access` 提权意味着该单条命令在沙箱外运行——批准前请阅读理由。
- 本预设的文件系统行使用预设领域内的裸本地 FS provider（与上游 Standard 相同）；使用本预设的会话中，宿主沙箱 FS 被遮蔽。
- 无运行时代码执行功能（无 staging/`new Function` 工具），无网络调用，无遥测；仅导入 `node:` 内置模块。

## 开发

```
npm run check   # 对所有插件文件做语法门禁（8→23 个文件）
npm test        # 单元测试 + fake-ctx 接缝测试（无需 DSH）
```

- 研究与设计：`RESEARCH.md`、`TECH-BEHAVIOR.md`、`TECH-INFRA.md`、`PLUGIN-SYNTHESIS.md`
- Agent 约定：`AGENTS.md`、`docs/agents/`

## 致谢

- **whoami 锚定**（`anchorMode: 'whoami'`，默认）改编自 [xiaobright/dsh-anchored-standard](https://github.com/xiaobright/dsh-anchored-standard) 的 `whoami-standard/` 变体——其 `whoami-turn` 机制与 `你是谁` 锚定文本。特别感谢 **xiaobright** 提供的这个想法。
- dsh-fusion 还融合了以下项目的思路：[yjh051108/dsh-router-standard](https://github.com/yjh051108/dsh-router-standard)（双语任务带路由与 persona）、[liceses/dsh-gitbash-preset](https://github.com/liceses/dsh-gitbash-preset)（win32 Git Bash 执行器与宿主安装器桥接）、[0liveiraaa/myDshPresets](https://github.com/0liveiraaa/myDshPresets)（预热回放），以及 [yjh051108/dsh-routing-suite](https://github.com/yjh051108/dsh-routing-suite)（打包与工程纪律）。

## 许可证

MIT。内置的 `agent.cordis.yml` 派生自 DeepSeek Harness Standard 预设组合（rc.6 快照），经由 [yjh051108/dsh-router-standard](https://github.com/yjh051108/dsh-router-standard) —— 见 `NOTICE` 与 `LICENSE.deepseek-harness`。
