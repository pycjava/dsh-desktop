// dev_tool_search: the discovery tool that makes the heavy Standard catalog one
// search away after promotion. The tool/call itself IS the unlock — its
// persisted arguments (toolNames) are replayed by the assemble filter, so the
// unlock survives resume with zero extra state.

import * as core from './fusion-core.mjs'

export const name = 'fusion-dev-tool-search'

export const inject = ['tools']

// Minimal JSON-schema subset compiler — preset-local modules cannot import
// @deepseek-ai/* (bare specifiers resolve against the user's home), so the
// schema is spelled out by hand.
const PARAMETERS = {
  type: 'object',
  properties: {
    query: { type: 'string', description: 'What you are looking for' },
    toolNames: {
      type: 'array',
      items: { type: 'string' },
      description: 'Exact tool names to unlock into the catalog',
    },
  },
}

const CAPABILITY_HINT = [
  'web_search — web search',
  'subagent / subagent_fork — delegation',
  'tool-workflow / tool-ralph — long-running workflows',
  'todo_write / ask_user_question — planning and clarification',
  'read / write / edit / glob / grep — filesystem detail work',
].join('\n')

export function apply(ctx, _config = {}) {
  ctx.tools.register({
    name: 'dev_tool_search',
    description:
      'Search and unlock tools. Tools you unlock here appear in your catalog from the next request. Available capabilities include:\n' +
      CAPABILITY_HINT,
    parameters: PARAMETERS,
    output: core.textOutput(),
    async execute(args = {}) {
      const wanted = Array.isArray(args.toolNames) ? args.toolNames.filter((n) => typeof n === 'string') : []
      if (wanted.length === 0) {
        return { text: 'Pass toolNames: [...] to unlock specific tools. Capabilities:\n' + CAPABILITY_HINT }
      }
      return {
        text:
          `Unlocked (visible from your next request): ${wanted.join(', ')}.\n` +
          'This call is durable — the unlock survives resume.',
      }
    },
  })
}
