// Optional warmup replay layer (default OFF). Ported from the
// warmupbetter-replay mechanics: seed a synthetic warmup turn before the first
// real user message, then SHORT-CIRCUIT the first model call by replaying a
// recorded chunk stream — a documented llm/stream veto (never calling next()
// means the adapter and all provider I/O never run). The synthetic stream
// faithfully mimics the adapter chunk protocol, so the agent loop still records
// assistant/message — which is exactly the promotion signal, so the session
// unlocks the full catalog on round two as if a real call had happened.
//
// Fail-soft everywhere: a broken/missing replay file disables only the veto
// (warn once); a failed route pre-check skips the warmup entirely — a real
// user message must NEVER be swallowed.

import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { randomUUID } from 'node:crypto'

export const name = 'fusion-warmup-replay'

export const inject = []

function loadReplay(replayFile) {
  try {
    const parsed = JSON.parse(readFileSync(replayFile, 'utf8'))
    if (typeof parsed.reasoning === 'string' && typeof parsed.reply === 'string' && parsed.reasoning.length > 0) return parsed
    return undefined
  } catch {
    return undefined
  }
}

async function* replayStream(replay, signal) {
  const guarded = (chunk) => {
    if (signal?.aborted) throw new Error('replay aborted')
    return chunk
  }
  yield guarded({ type: 'block-start', index: 0, blockType: 'reasoning' })
  yield guarded({ type: 'reasoning-delta', index: 0, text: replay.reasoning })
  yield guarded({ type: 'block-end', index: 0, block: { type: 'reasoning', text: replay.reasoning } })
  yield guarded({ type: 'block-start', index: 1, blockType: 'text' })
  yield guarded({ type: 'text-delta', index: 1, text: replay.reply })
  yield guarded({ type: 'block-end', index: 1, block: { type: 'text', text: replay.reply } })
  yield guarded({ type: 'finish', reason: { kind: 'stop' } })
}

export function apply(ctx, config = {}) {
  if (config.enabled !== true) return

  const replayUrl = config.replayFile
    ? new URL(config.replayFile, import.meta.url)
    : new URL('./replay.json', import.meta.url)
  const replay = loadReplay(fileURLToPath(replayUrl))
  if (replay === undefined) {
    ctx.logger?.warn(`[fusion] warmup replay: cannot load ${config.replayFile ?? './replay.json'} — veto disabled, warmup rounds will use the real model`)
    return
  }

  const warmupText = config.message ?? 'Warmup round: think through how you will approach the upcoming task. Do not use tools yet.'
  const pending = new WeakSet() // fresh sessions armed at inbox insert
  const replaySessions = new Set() // session ids whose NEXT llm call is vetoed

  ctx.on('agent/inbox/inserted', ({ agent, message }) => {
    if (message?.source?.kind === 'plugin') return // never re-trigger on our own seeds
    const session = agent?.session
    if (session === undefined) return
    if (session.header?.meta?.origin === 'subagent') return
    if ((session.events ?? []).some((event) => event.type === 'request/header')) return // resumed session
    pending.add(agent)
  })

  ctx.on(
    'agent/pre-step',
    async ({ agent }, next) => {
      const decision = await next()
      if (decision.kind === 'reject') return decision
      if (!pending.has(agent)) return decision
      pending.delete(agent)

      // Route pre-check: if the routing waterfall cannot resolve, skip the
      // warmup — the real message must go through untouched.
      try {
        await agent.dispatch.waterfall('agent/request', { turn: 0, step: 0, signal: undefined }, async () => ({}))
      } catch (error) {
        ctx.logger?.warn(`[fusion] warmup skipped (route pre-check failed): ${error?.message ?? error}`)
        return decision
      }

      for (const message of decision.messages ?? []) agent.inbox.prepend('next-turn', message)
      replaySessions.add(agent.session.id)
      return {
        ...decision,
        kind: 'enter',
        messages: [
          {
            id: randomUUID(),
            role: 'user',
            content: [{ type: 'text', text: warmupText }],
            source: { kind: 'plugin', plugin: 'fusion-warmup', form: 'notice', summary: 'warmup replay round' },
          },
        ],
      }
    },
    { prepend: true },
  )

  ctx.on('llm/stream', (options, next) => {
    if (options?.sessionId === undefined || !replaySessions.has(options.sessionId)) return next()
    replaySessions.delete(options.sessionId)
    return replayStream(replay, options.signal)
  })
}
