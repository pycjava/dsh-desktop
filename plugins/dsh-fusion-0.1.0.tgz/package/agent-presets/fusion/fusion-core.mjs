// Pure decision logic for the fusion preset. Zero imports, zero host types —
// the unit-test seam. Every plugin module consumes this via namespace import
// (`import * as core from './fusion-core.mjs'`) so a missing symbol fails at
// syntax-check time, never as a runtime ReferenceError mid-session.

// The Minimal anchor pair (rc.6): persistent-schema `bash` (from
// dsh-tool-bash-persistent on unix, the byte-identical gitbash tool on win32)
// + `str_replace_editor` (dsh-tool-str-replace-editor). Standard's editor is
// `edit` and Standard's bash is a different schema — neither is the pair.
// `pwsh` never reaches the anchor round (pickBootstrapSet drops the losing
// shell) but stays in the post-promotion resident set on win32.
export const DEFAULT_BOOTSTRAP_TOOLS = ['bash', 'pwsh', 'str_replace_editor']
export const DEFAULT_SHELL_PRIORITY = ['bash', 'pwsh']
export const DEFAULT_COMPACTION_TOOLS = [
  'read', 'write', 'edit', 'glob', 'grep', 'todo_write', 'ask_user_question',
]
export const DEFAULT_DISCOVERY_TOOLS = ['dev_tool_search']
// Always-on tools that are NOT part of the Minimal anchor pair. They only
// enter the catalog after promotion, so they never disturb the anchor round.
export const DEFAULT_RESIDENT_TOOLS = ['modlens_read_image']
export const DEFAULT_SUPPRESSED_SOURCES = ['agent-instructions', 'skill-catalog']

// ── task routing (ported from the router-standard findings) ─────────────────
// Pure bilingual keyword counting — deterministic, zero model calls. Ties and
// double-misses fall to 'weak': the model self-classifies rather than getting
// a wrong hard mode (a wrong mode costs ~10 points; weak costs nothing).

const REACT_RE = /(开发|创建|写一个|生成|从零|做一个|游戏|网页|网站|构建|新项目|搭建|实现|做出|上线|落地|脚本|工具|应用|build|create|develop|generate|implement|make a|new project)/gi
const SPEC_RE = /(修复|修一下|调试|重构|维护|排查|报错|出错|崩溃|优化|审查|review|fix|debug|refactor|maintain|repair|broken|break|为什么|异常|故障|迁移|升级|兼容)/gi

const countHits = (re, text) => (String(text ?? '').match(re) ?? []).length

export function classifyTask(text) {
  const react = countHits(REACT_RE, text)
  const spec = countHits(SPEC_RE, text)
  if (react > spec) return 1
  if (spec > react) return 0
  return 'weak'
}

// The persona axis is not a continuum: measured behavior sits in stable bands
// separated by a transition trap (0.2–0.5) that automatic routing NEVER picks.
export function bandOf(mode) {
  if (mode === 'weak') return 'weak'
  const clamped = Math.min(1, Math.max(0, Number(mode)))
  if (!Number.isFinite(clamped)) return 'weak'
  if (clamped < 0.2) return 'spec'
  if (clamped < 0.5) return 'transition'
  return 'react'
}

// dev_router_mode accepts band names and numeric input; numbers quantize into
// the three bands. 'weak' and 'auto' hand routing back to the model.
export function parseMode(input) {
  if (input === undefined || input === null) return undefined
  if (typeof input === 'number' && Number.isFinite(input)) {
    if (input > 1) return input / 100 <= 1 ? input / 100 : 1
    return input
  }
  const named = { spec: 0, 'spec-lean': 0.1, balanced: 0.5, mixed: 0.35, 'react-lean': 0.6, react: 1, weak: 'weak', router: 'weak', auto: 'weak' }
  const value = named[String(input).toLowerCase()]
  return value !== undefined ? value : undefined
}

export const BAND_CORE = {
  spec: ['read', 'edit', 'glob', 'grep'], // read-first: maintenance/fix
  transition: ['read', 'write', 'edit', 'glob', 'grep'], // manual override only
  react: ['read', 'write', 'edit'], // write-first: greenfield/build
}

export function coreFor(band) {
  return BAND_CORE[band] ?? null
}

export function winningShell(catalogNames, shellPriority = DEFAULT_SHELL_PRIORITY) {
  const catalog = new Set(catalogNames)
  return shellPriority.find((name) => catalog.has(name)) ?? null
}

// Every band persona opens with the exact Minimal persona sentence, so the
// system prompt's first bytes never change across the session — the anchor
// head survives promotion and only the steering tail differs per band. Tails
// are identity statements in we-voice. Meta-demands like "state which you
// chose in one short line" are deliberately absent: the model echoed one
// verbatim and immediately re-framed into first-person "Let me …" style
// (session a104, step 2). Weak stays model-shaped (Pro leans spec-first,
// Flash gets the shorter lane-picker).
export const ANCHOR_PERSONA_HEAD = 'You are a helpful software engineer assistant.'

// Identity-anchor round text. Bytes match the A/B-tested whoami run (session
// 9154: we×36 / me×0 across 18 tool-carrying steps) — change with care.
export const WHOAMI_ANCHOR_TEXT = '你是谁'
const tail = (text) => `${ANCHOR_PERSONA_HEAD} ${text}`
const PERSONAS = {
  spec: tail(
    'For maintenance and fixes we work spec-first: we read the relevant code, we plan, then we make the minimal well-grounded change.',
  ),
  transition: tail(
    'We size the task first — spec-first (read, plan, minimal change) for maintenance, execution-first for new builds — then we proceed.',
  ),
  react: tail(
    'We build hands-on: we reach working code quickly, iterate in small verifiable steps, and keep momentum.',
  ),
  weakPro: tail(
    'We size the task ourselves — spec-first for maintenance and fixes, execution-first for new builds — then we proceed.',
  ),
  weakFlash: tail(
    'We pick our lane — careful spec-first for maintenance, quick execution-first for new builds — then proceed.',
  ),
}

export function isFlashModel(modelId) {
  return /flash/i.test(String(modelId ?? ''))
}

export function personaFor(band, modelId) {
  if (band === 'weak') return isFlashModel(modelId) ? PERSONAS.weakFlash : PERSONAS.weakPro
  return PERSONAS[band] ?? PERSONAS.weakPro
}

// The prompt stays persona-sized for the WHOLE session. Post-promotion the
// persona section keeps its slot but its text becomes the band persona —
// the full Standard prompt never returns: restoring it was measured to flip
// the model straight back to a standard-like trajectory ("We need…" at round
// 1 became "Let me" the moment the 6k-char prompt returned at promotion).
// Returns null when no persona section exists (fail-soft: keep sections).
export function personaSwap(sections, personaText) {
  const persona = (sections ?? []).find((section) => /persona/i.test(section?.name ?? ''))
  if (persona === undefined) return null
  return personaText === undefined ? [persona] : [{ ...persona, text: personaText }]
}

// The anchor round's system prompt: official Minimal's complete prompt is its
// persona section alone, so round 1 keeps exactly that section (whatever the
// persona row is configured to say) and nothing else — no identity, no tool
// guidance, no context sections. Post-promotion the Standard prompt returns.
// The section is registered as `deployment:persona` (PERSONA_SECTION in
// dsh-system-prompt) — match by pattern, like applyPersona does; an exact
// `=== 'persona'` check once silently no-oped and round 1 shipped the full
// Standard prompt.
export function anchorSections(sections) {
  const persona = (sections ?? []).find((section) => /persona/i.test(section?.name ?? ''))
  return persona === undefined ? null : [persona]
}

// Extract the first REAL user message text from the durable log. Synthetic
// plugin-source messages (warmup rounds) are skipped; data shapes are unwrapped
// defensively.
export function extractUserText(session) {
  for (const event of session.events ?? []) {
    if (event.type !== 'user/message') continue
    const data = event.data ?? event
    const source = data.source ?? event.source
    if (source?.kind && source.kind !== 'user') continue
    const message = data.message ?? data
    const content = message?.content ?? data.content
    if (typeof content === 'string') return content
    if (Array.isArray(content)) {
      const text = content.filter((part) => part?.type === 'text').map((part) => part.text).join('\n')
      if (text.length > 0) return text
    }
  }
  return ''
}

export function sessionMode(session) {
  return classifyTask(extractUserText(session))
}

// ── near-field guidance (weak sessions only) ────────────────────────────────
// Injected AFTER a real user message — the P14/P16/P20 finding: the same
// instruction decays or reverses in the system prompt, but holds when it rides
// next to the message. Fixed texts keep the request prefix cache intact.

const COMPLEX_RE = /(架构|设计|重构|迁移|整体|方案|architect|design|refactor|migrat|system|end-to-end|multi)/i

export function isComplexTask(text) {
  const value = String(text ?? '')
  return value.length > 120 || COMPLEX_RE.test(value)
}

export function guideFor(text) {
  return isComplexTask(text)
    ? 'Before acting: recall what is already done, check whether the information you have is sufficient to produce the deliverable, and if it is, produce it now. Do not re-inspect the environment or grep exhaustively — decide and close.'
    : 'Take the next concrete step: decide, act, report. Keep it small and verify it.'
}

// The first-round keep-set: every non-shell bootstrap tool present in the
// catalog, plus exactly ONE shell — the highest-priority one available. On a
// win32 catalog that is the gitbash-backed `bash`; on unix the persistent
// `bash`; `pwsh` only when it is the sole shell.
export function pickBootstrapSet(catalogNames, bootstrapTools = DEFAULT_BOOTSTRAP_TOOLS, shellPriority = DEFAULT_SHELL_PRIORITY) {
  const catalog = new Set(catalogNames)
  const present = bootstrapTools.filter((name) => catalog.has(name))

  const shells = present.filter((name) => shellPriority.includes(name))
  const winningShell = [...shellPriority].sort((a, b) => shellPriority.indexOf(a) - shellPriority.indexOf(b)).find((name) => shells.includes(name))

  const keep = new Set(present.filter((name) => !shellPriority.includes(name)))
  if (winningShell !== undefined) keep.add(winningShell)
  return keep
}

// Does the assembled catalog actually contain anything we meant to keep?
// An empty keep-set means our bootstrap names match nothing in this host —
// fail-soft callers should pass the catalog through untouched.
export function keepSetIsUsable(keep, catalogNames) {
  if (keep.size === 0) return false
  const catalog = new Set(catalogNames)
  for (const name of keep) if (catalog.has(name)) return true
  return false
}

// Non-shell bootstrap tools must ALL exist in the catalog — a missing shell is
// platform-normal (that is what shellPriority fallbacks are for), but a missing
// editor silently degrades the anchor pair, so callers warn (once) about these.
export function missingAnchorTools(catalogNames, bootstrapTools = DEFAULT_BOOTSTRAP_TOOLS, shellPriority = DEFAULT_SHELL_PRIORITY) {
  const catalog = new Set(catalogNames)
  return bootstrapTools.filter((name) => !shellPriority.includes(name) && !catalog.has(name))
}

// The post-promotion resident set: minimal pair + resident tools + discovery
// tools + the band's core tools + everything the model itself unlocked by
// calling dev_tool_search. The heavy Standard catalog stays one search away
// instead of being dumped (which measurably regresses post-promotion
// behavior). Band cores and resident tools live HERE, never in round 1: every
// standard-like keep-set failed to anchor (#11), so routing may only shape the
// session once the anchor round is spent.
export function promotedKeepSet(bootstrapTools, discoveryTools, bandCore = [], unlocked = new Set(), residentTools = DEFAULT_RESIDENT_TOOLS) {
  const keep = new Set([...bootstrapTools, ...discoveryTools, ...residentTools, ...bandCore])
  for (const name of unlocked) keep.add(name)
  return keep
}

// Replay unlock state from the durable event log: every persisted dev_tool_search
// call's arguments carry a toolNames array. Defensive by design — a malformed
// payload skips that call, never throws.
export function unlockedFor(session) {
  const unlocked = new Set()
  for (const event of session.events ?? []) {
    if (event.type !== 'tool/call') continue
    const data = event.data ?? event
    const called = data.name ?? data.tool
    if (called !== 'dev_tool_search') continue
    const raw = data.arguments ?? data.args
    if (raw === undefined) continue
    let parsed = raw
    if (typeof raw === 'string') {
      try {
        parsed = JSON.parse(raw)
      } catch {
        continue
      }
    }
    for (const name of parsed?.toolNames ?? []) {
      if (typeof name === 'string') unlocked.add(name)
    }
  }
  return unlocked
}

// Hosts since rc.6 refuse a tools.register() without an output contract: the
// host validates the execute() value against output.schema at call time and
// takes the model-facing content from output.render — a {text} return alone no
// longer reaches the transcript. This is the shared declaration for the
// text-only dev_* results; the tools themselves stay hand-rolled (preset-local
// modules cannot import @deepseek-ai/*).
export function textOutput(extraProperties = {}) {
  return {
    schema: {
      type: 'object',
      additionalProperties: false,
      required: ['text', ...Object.keys(extraProperties)],
      properties: {
        text: { type: 'string', description: 'Plain-text result for the model' },
        ...extraProperties,
      },
    },
    render: (_args, value) => [{ type: 'text', text: value.text }],
  }
}
