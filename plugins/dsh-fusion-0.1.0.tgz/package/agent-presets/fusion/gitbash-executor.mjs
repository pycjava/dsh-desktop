// win32 shell backend: maps the `bash` tool onto Git for Windows (MSYS) via
// `<git bash> -c <command>` — one fresh shell per command, because a persistent
// PTY session is impossible on win32 (the MSYS runtime cannot create its
// signal pipes under a restricted token). Ported from the dsh-gitbash-preset
// design with one deliberate change: no hardcoded author-machine paths.
//
// The service this provides must satisfy the `ctx.shell` seam exactly as
// dsh-tool-bash consumes it (the dsh-bash-local shape):
//   - resolve(request) fills workdir/timeoutMs/stdoutMaxBytes defaults before
//     every run/start — the tool calls it unconditionally;
//   - run() returns the canonical result: exit facts spread from the
//     subprocess outcome plus timedOut/aborted/timeoutMs and stream objects
//     { text, truncated, spillPath? } projected from the collect readers —
//     `done` never carries output text, and the tool canonicalizes these
//     fields directly into the model-facing result;
//   - the executor owns the timeout: the subprocess spawn spec has no
//     timeoutMs field, only an abort `signal` fused from the caller's
//     cancellation and the deadline, whose reason classifies the settlement.
//
// Only node: builtins. `inject: ['subprocess', 'sandboxPolicy']` — both host
// services, consumed immediately at apply() time.

import { existsSync } from 'node:fs'

export const name = 'fusion-gitbash-executor'

export const inject = ['subprocess', 'sandboxPolicy']

// Interactive pagers and color escapes would poison collected output.
const ENV_OVERRIDES = { NO_COLOR: '1', TERM: 'dumb', PAGER: 'cat', GIT_PAGER: 'cat' }

// ── pure helpers (unit-test seam) ───────────────────────────────────────────

// Convert single-drive MSYS paths (/d/foo, /d/, /d) to Windows form. MSYS roots
// like /usr/bin are deliberately left alone; UNC and native paths pass through.
export function toWindowsPath(path) {
  if (typeof path !== 'string' || path.length === 0) return path
  if (/^[a-zA-Z]:/.test(path) || path.startsWith('\\\\') || path.startsWith('//')) return path
  const match = /^\/([a-zA-Z])(\/.*)?$/.exec(path)
  if (match === null) return path
  const rest = (match[2] ?? '').replace(/\//g, '\\')
  return `${match[1].toUpperCase()}:${rest}`
}

// Ordered detection chain: explicit config > GIT_BASH env > the usual install
// dirs > every PATH entry > bare 'bash' (let spawn produce the resolution
// error). No machine-specific hardcoded entries.
export function shellPathCandidates({ shellPath, env = {}, pathEntries = [] }) {
  const candidates = []
  if (typeof shellPath === 'string' && shellPath.length > 0) candidates.push(toWindowsPath(shellPath))
  if (typeof env.GIT_BASH === 'string' && env.GIT_BASH.length > 0) candidates.push(toWindowsPath(env.GIT_BASH))
  for (const root of [env.ProgramFiles, env['ProgramFiles(x86)']]) {
    if (typeof root === 'string' && root.length > 0) candidates.push(`${root}\\Git\\bin\\bash.exe`)
  }
  if (typeof env.LOCALAPPDATA === 'string' && env.LOCALAPPDATA.length > 0) {
    candidates.push(`${env.LOCALAPPDATA}\\Programs\\Git\\bin\\bash.exe`)
  }
  for (const dir of pathEntries) candidates.push(`${dir}\\bash.exe`)
  return candidates
}

export function detectShellPath({ shellPath, env = {}, pathEntries = [], platform = process.platform, probe = existsSync }) {
  if (platform !== 'win32') return typeof shellPath === 'string' && shellPath.length > 0 ? shellPath : 'bash'
  for (const candidate of shellPathCandidates({ shellPath, env, pathEntries })) {
    if (probe(candidate)) return candidate
  }
  return 'bash'
}

export function resolveConfig(config = {}) {
  const timeoutMs = config.timeoutMs ?? 120000
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new Error('gitbash-executor: timeoutMs must be a positive finite number')
  const maxOutputBytes = config.maxOutputBytes ?? 64000
  if (!Number.isFinite(maxOutputBytes) || maxOutputBytes <= 0) throw new Error('gitbash-executor: maxOutputBytes must be a positive finite number')
  return { timeoutMs, maxOutputBytes, graceMs: config.graceMs ?? 3000, maxSpillBytes: config.maxSpillBytes ?? 64 * 1024 * 1024 }
}

export function clampTimeout(requestMs, defaultMs, hardMaxMs = 600000) {
  const value = Number.isFinite(requestMs) && requestMs > 0 ? requestMs : defaultMs
  return Math.min(value, hardMaxMs)
}

function assertPositiveFinite(name, value) {
  if (!Number.isFinite(value) || value <= 0) throw new Error(`gitbash-executor: ${name} must be a positive finite number`)
}

export const FULL_ACCESS = 'danger-full-access'

// undefined mode means the deployment itself has no sandbox policy — allow.
export function gateAllows(mode) {
  return mode === undefined || mode === FULL_ACCESS
}

export function gateMessage(mode) {
  return (
    `fusion-gitbash-executor: the Git-for-Windows bash runtime cannot start inside the "${mode}" sandbox ` +
    '(the MSYS runtime cannot create its signal pipes under the restricted token). ' +
    `Retry this exact command once with sandbox_permissions: "${FULL_ACCESS}" plus a justification, ` +
    'or ask the user to switch the session sandbox mode to full access.'
  )
}

function spawnErrorMessage(shellPath, workdir, cause) {
  return `failed to start ${shellPath} (workdir: ${workdir ?? ''}): ${cause?.message ?? cause}`
}

// Timeout code stamped on the abort reason; a settled run is `timedOut` when
// the fused signal carries it, `aborted` when it carries anything else.
const TIMEOUT_CODE = 'BASH_TIMEOUT'

function timeoutReason(timeoutMs) {
  const error = new Error(`${TIMEOUT_CODE} after ${timeoutMs}ms`)
  error.code = TIMEOUT_CODE
  return error
}

// Fuse the caller's cancellation with an identifiable deadline — the local
// equivalent of @deepseek-ai/dsh-timeout's deadline(). The fused signal is
// what reaches ctx.subprocess; the disposer clears the armed timer.
function deadline(upstream, timeoutMs) {
  if (timeoutMs <= 0) return { signal: upstream ?? new AbortController().signal, dispose() {} }
  const timer = new AbortController()
  const id = setTimeout(() => timer.abort(timeoutReason(timeoutMs)), timeoutMs)
  return {
    signal: upstream !== undefined ? AbortSignal.any([upstream, timer.signal]) : timer.signal,
    dispose() {
      clearTimeout(id)
    },
  }
}

function isTimeout(signal) {
  return signal.aborted === true && signal.reason?.code === TIMEOUT_CODE
}

// The collect reader a spawn requested (present by construction, since both
// streams spawn with a maxBytes disposition); defensive, like dsh-bash-local.
function collectedFrom(handle, name) {
  const reader = handle.collected?.[name]
  if (reader === undefined) throw new Error(`fusion-gitbash-executor: subprocess implementation dropped the requested ${name} collect stream`)
  return reader
}

// Project a settled collect reader into the final stream shape the bash tool
// canonicalizes: { text, truncated, spillPath? }.
function finalOutput(reader) {
  const read = reader.readFrom(0)
  return { text: read.text, truncated: read.lossy, ...(read.spillPath !== undefined ? { spillPath: read.spillPath } : {}) }
}

// ── plugin ──────────────────────────────────────────────────────────────────

export function apply(ctx, config = {}) {
  const subprocess = ctx.get('subprocess')
  const sandboxPolicy = ctx.get ? ctx.get('sandboxPolicy') : undefined
  const resolved = resolveConfig(config)

  const executor = {
    get sandboxMode() {
      return sandboxPolicy?.defaultMode
    },

    // Fill the fully-specified spec: workdir from config.cwd (else
    // process.cwd()), timeoutMs from the default capped at the hard max,
    // stdoutMaxBytes from the output budget; everything caller-owned passes
    // through untouched. The tool layer calls this before run/start, so those
    // methods receive explicit values and never re-default.
    resolve(request = {}) {
      if (request.timeoutMs !== undefined) assertPositiveFinite('request.timeoutMs', request.timeoutMs)
      if (request.stdoutMaxBytes !== undefined) assertPositiveFinite('request.stdoutMaxBytes', request.stdoutMaxBytes)
      return {
        command: request.command,
        workdir: request.workdir ?? config.cwd ?? process.cwd(),
        timeoutMs: clampTimeout(request.timeoutMs, resolved.timeoutMs),
        stdoutMaxBytes: request.stdoutMaxBytes ?? resolved.maxOutputBytes,
        ...(request.signal !== undefined ? { signal: request.signal } : {}),
        ...(request.stdin !== undefined ? { stdin: request.stdin } : {}),
        ...(request.env !== undefined ? { env: request.env } : {}),
        ...(request.dshEnv !== undefined ? { dshEnv: request.dshEnv } : {}),
        sandboxPolicy: request.sandboxPolicy,
      }
    },

    async run(spec = {}) {
      const mode = spec.sandboxPolicy?.mode
      if (!gateAllows(mode)) throw new Error(gateMessage(mode))

      const workdir = toWindowsPath(spec.workdir ?? config.cwd ?? process.cwd())
      const shellPath = detectShellPath({ shellPath: config.shellPath, env: { ...process.env, ...(spec.env ?? {}) } })
      const timeoutMs = clampTimeout(spec.timeoutMs, resolved.timeoutMs)
      const fuse = deadline(spec.signal, timeoutMs)

      try {
        const proc = subprocess.spawn({
          argv: [shellPath, '-c', spec.command],
          cwd: workdir,
          stdio: {
            stdin: spec.stdin !== undefined ? { data: spec.stdin } : 'ignore',
            stdout: { maxBytes: spec.stdoutMaxBytes ?? resolved.maxOutputBytes, spill: { maxBytes: resolved.maxSpillBytes } },
            stderr: { maxBytes: resolved.maxOutputBytes, spill: { maxBytes: resolved.maxSpillBytes } },
          },
          graceMs: resolved.graceMs,
          signal: fuse.signal,
          env: { ...ENV_OVERRIDES, ...(spec.env ?? {}), ...(spec.dshEnv ?? {}) },
        })
        const outcome = await proc.done
        const timedOut = isTimeout(fuse.signal)
        return {
          ...outcome,
          timedOut,
          aborted: fuse.signal.aborted && !timedOut,
          timeoutMs,
          stdout: finalOutput(collectedFrom(proc, 'stdout')),
          stderr: finalOutput(collectedFrom(proc, 'stderr')),
          sandbox: { mode, denied: false },
        }
      } catch (error) {
        if (error instanceof Error && error.message.startsWith('fusion-gitbash-executor:')) throw error
        throw new Error(spawnErrorMessage(shellPath, workdir, error), { cause: error })
      } finally {
        fuse.dispose()
      }
    },

    // Background lifecycle: register-able with ctx.jobs, shaped exactly like
    // dsh-bash-local's handle — status/exitCode/signal stamped at settlement,
    // offset-based delta reads, idempotent kill through the tree terminate.
    start(spec = {}) {
      const mode = spec.sandboxPolicy?.mode
      if (!gateAllows(mode)) throw new Error(gateMessage(mode))

      const workdir = toWindowsPath(spec.workdir ?? config.cwd ?? process.cwd())
      const shellPath = detectShellPath({ shellPath: config.shellPath, env: { ...process.env, ...(spec.env ?? {}) } })
      const running = subprocess.spawn({
        argv: [shellPath, '-c', spec.command],
        cwd: workdir,
        stdio: {
          stdin: spec.stdin !== undefined ? { data: spec.stdin } : 'ignore',
          stdout: { maxBytes: resolved.maxOutputBytes, spill: { maxBytes: resolved.maxSpillBytes } },
          stderr: { maxBytes: resolved.maxOutputBytes, spill: { maxBytes: resolved.maxSpillBytes } },
        },
        graceMs: resolved.graceMs,
        ...(spec.signal !== undefined ? { signal: spec.signal } : {}),
        env: { ...ENV_OVERRIDES, ...(spec.env ?? {}), ...(spec.dshEnv ?? {}) },
      })
      const streams = { stdout: collectedFrom(running, 'stdout'), stderr: collectedFrom(running, 'stderr') }
      let stdoutOffset = 0
      let stderrOffset = 0
      let spawnFailureNote
      const consumeSpawnFailure = () => {
        const note = spawnFailureNote ?? ''
        spawnFailureNote = undefined
        return note
      }

      const proc = {
        status: 'running',
        exitCode: null,
        signal: null,
        done: running.done.then(
          (outcome) => {
            if (proc.status === 'running') proc.status = spec.signal?.aborted === true || outcome.signal !== null ? 'killed' : 'completed'
            proc.exitCode = outcome.exitCode
            proc.signal = outcome.signal
          },
          (error) => {
            proc.status = 'killed'
            spawnFailureNote = `spawn failed: ${String(error)}`
          },
        ),
        readOutput() {
          const out = streams.stdout.readFrom(stdoutOffset)
          const err = streams.stderr.readFrom(stderrOffset)
          stdoutOffset = out.nextOffset
          stderrOffset = err.nextOffset
          const errText = err.text.length > 0 ? err.text : consumeSpawnFailure()
          const separator = out.text.length > 0 && !out.text.endsWith('\n') ? '\n' : ''
          return {
            delta: out.text + (errText.length > 0 ? `${separator}[stderr]\n${errText}` : ''),
            lossy: out.lossy || err.lossy,
            ...(out.spillPath !== undefined ? { stdoutSpillPath: out.spillPath } : {}),
            ...(err.spillPath !== undefined ? { stderrSpillPath: err.spillPath } : {}),
          }
        },
        kill() {
          if (proc.status !== 'running') return false
          proc.status = 'killed'
          running.terminate()
          return true
        },
      }
      return proc
    },
  }

  ctx.provide('shell', executor)
}
