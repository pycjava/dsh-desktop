// Epoch-aware promotion state machine, ported from the anchored-standard
// design: phase is DERIVED from durable session events, never stored — so
// resume/reload stays correct with zero persistence of our own.
//
//   promotion signal : `tool/call` and/or `assistant/message` (configurable)
//   epoch boundary   : `compaction/end` — after a fold the session returns to
//                      the controlled (unpromoted) phase until a NEW signal
//   always promoted  : host-plane assembly (agent === undefined); subagent
//                      sessions too, UNLESS subagent anchoring is on
//                      ({ prePromoteSubagents: false }) — then they follow the
//                      same epoch promotion as the top-level session

export const PROMOTE_EVENT_SETS = {
  'tool-call': ['tool/call'],
  'assistant-message': ['assistant/message'],
  either: ['tool/call', 'assistant/message'],
}

export function createEpochPromotion(promoteEvents, { prePromoteSubagents = true } = {}) {
  const promote = new Set(promoteEvents)
  const state = new Map() // session.id -> { boundary, promoted, scanned }

  const scan = (session) => {
    let boundary = -1
    let promoted = false
    for (const event of session.events ?? []) {
      const seq = event.seq ?? 0
      if (event.type === 'compaction/end') {
        boundary = seq
        promoted = false
        continue
      }
      if (promote.has(event.type) && seq > boundary) promoted = true
    }
    return { boundary, promoted }
  }

  return {
    status(agent) {
      if (agent === undefined) return { promoted: true, boundary: -1 }
      const session = agent.session ?? agent
      // With subagent anchoring on, subagent sessions follow the same epoch
      // promotion as the top-level session (their anchor reply promotes).
      if (prePromoteSubagents && (session.header?.delegationDepth ?? 0) > 0) return { promoted: true, boundary: -1 }
      let entry = state.get(session.id)
      if (entry === undefined || !entry.scanned) {
        entry = { ...scan(session), scanned: true }
        state.set(session.id, entry)
      }
      return { promoted: entry.promoted, boundary: entry.boundary }
    },

    observe(session, event) {
      let entry = state.get(session.id)
      if (entry === undefined) {
        entry = { ...scan(session), scanned: true }
        state.set(session.id, entry)
      }
      if (event.type === 'compaction/end') {
        entry.boundary = event.seq ?? 0
        entry.promoted = false
        return
      }
      if (promote.has(event.type) && (event.seq ?? 0) > entry.boundary) entry.promoted = true
    },
  }
}
