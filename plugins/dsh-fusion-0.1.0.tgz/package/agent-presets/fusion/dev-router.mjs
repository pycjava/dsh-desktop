// dev_* self-optimization tools: expose the routing to the model itself.
// Separate module from the bootstrap on purpose — different service injections
// (tools/llm); the shared state lives in routing-state.mjs.
//
// All dev_* tools are excluded from every first-round keep-set, so they only
// exist in the catalog after promotion — they can never eat the anchoring.

import * as core from './fusion-core.mjs'
import { routingState } from './routing-state.mjs'

export const name = 'fusion-dev-router'

export const inject = ['tools', 'llm']

const PARAMETERS = {
  type: 'object',
  properties: {},
  required: [],
}

const MODE_PARAMETERS = {
  type: 'object',
  properties: {
    mode: {
      type: 'string',
      description: 'spec | react | balanced | mixed | weak | auto, or a number 0-1 / 0-100',
    },
    session_id: { type: 'string', description: 'Defaults to the current session' },
  },
  required: ['mode'],
}

const SUBAGENT_PARAMETERS = {
  type: 'object',
  properties: {
    mode: { type: 'string', description: 'Persona band for the isolated call: spec | react | ...' },
    task: { type: 'string', description: 'The single task to execute in isolation' },
  },
  required: ['mode', 'task'],
}

// rc.6 hosts validate the execute() value against this schema (additionalProperties:
// false), so the reply keys below are the full contract.
const SUBAGENT_OUTPUT = core.textOutput({
  reasoningChars: { type: 'integer', description: 'Reasoning-stream size in characters' },
  band: { type: 'string', description: 'Persona band the isolated call ran under' },
})

function currentBand(agent) {
  const session = agent?.session ?? {}
  const override = routingState.getOverride(session.id)
  return core.bandOf(override !== undefined ? override : core.sessionMode(session))
}

export function apply(ctx, _config = {}) {
  const llm = ctx.llm ?? ctx.get?.('llm')
  const register = (tool) => ctx.tools.register(tool)

  register({
    name: 'dev_router_status',
    description: 'Report the current routing: mode, band, persona, post-promotion core tools, override state.',
    parameters: PARAMETERS,
    output: core.textOutput(),
    async execute(args = {}) {
      const agent = routingState.agentFor(args.session_id)
      if (agent === undefined) return { text: 'no session assembled yet' }
      const session = agent.session ?? {}
      const band = currentBand(agent)
      const override = routingState.getOverride(session.id)
      return {
        text: JSON.stringify(
          {
            session: session.id,
            band,
            persona: core.personaFor(band, agent.options?.model).slice(0, 120) + '…',
            round1: 'anchored minimal pair (all bands)',
            promotedCore: core.coreFor(band) ?? 'none (weak)',
            override: override === undefined ? null : override,
            unlocked: [...core.unlockedFor(session)].sort(),
          },
          null,
          2,
        ),
      }
    },
  })

  register({
    name: 'dev_router_mode',
    description:
      'Override the routing mode for this session. Accepts band names (spec/react/balanced/mixed/weak/auto) or numbers (0-1 float, 0-100 int). Takes effect from the next request. Note: overrides are process-local and do not survive restart.',
    parameters: MODE_PARAMETERS,
    output: core.textOutput(),
    async execute(args = {}) {
      const mode = core.parseMode(args.mode)
      if (mode === undefined) return { text: `unrecognized mode: ${JSON.stringify(args.mode)}` }
      const agent = routingState.agentFor(args.session_id)
      const sessionId = args.session_id ?? agent?.session?.id
      if (sessionId === undefined) return { text: 'no session to override' }
      routingState.setOverride(sessionId, mode)
      return { text: `override set: mode=${mode} band=${core.bandOf(mode)} (next request onward)` }
    },
  })

  register({
    name: 'dev_mode_subagent',
    description:
      'Run ONE task in a fully isolated LLM call under a different persona band — without switching this session\'s mode (mid-session switches invalidate the request prefix cache). Returns the reply and a reasoning-size reading.',
    parameters: SUBAGENT_PARAMETERS,
    output: SUBAGENT_OUTPUT,
    async execute(args = {}) {
      const agent = routingState.agentFor(args.session_id)
      const mode = core.parseMode(args.mode) ?? 1
      const band = core.bandOf(mode)
      const provider = agent?.options?.provider ?? 'deepseek'
      const model = agent?.options?.model ?? 'deepseek-v4-pro'

      let text = ''
      let reasoningChars = 0
      for await (const chunk of llm.stream({
        provider,
        model,
        system: core.personaFor(band, model),
        messages: [{ role: 'user', content: String(args.task ?? '') }],
        maxTokens: 8192,
      })) {
        if (chunk?.type === 'text-delta') text += chunk.text ?? ''
        if (chunk?.type === 'reasoning-delta') reasoningChars += (chunk.text ?? '').length
      }
      return { text: text.slice(0, 3000), reasoningChars, band }
    },
  })
}
