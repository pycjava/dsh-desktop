// Cross-module routing state for the fusion preset: the bootstrap (which owns
// assemble/pre-step listeners) and the dev-router tools (a separate module with
// its own service injections) need to share the live agent handles and mode
// overrides. Bands are derived fresh on every assembly (no memoization — the
// classifier scans only up to the first real user message, and stale caches
// across resumed/renamed sessions cost more than they save).
//
// Process-local by design — the M2 transitional stance recorded in the spec:
// derived-from-events parts survive resume; the override Map does not
// (persisted override is M4 work).

const agents = new Map() // session.id -> live agent handle (cached during assemble)
const overrides = new Map() // session.id -> explicit mode from dev_router_mode
let lastAgent = undefined // most recent assembled agent — dev tools without a session id fall back to it

export const routingState = {
  cacheAgent(agent) {
    if (agent?.session?.id !== undefined) {
      agents.set(agent.session.id, agent)
      lastAgent = agent
    }
  },
  agentFor(sessionId) {
    if (sessionId !== undefined && agents.has(sessionId)) return agents.get(sessionId)
    return lastAgent
  },
  getOverride(sessionId) {
    return overrides.get(sessionId)
  },
  setOverride(sessionId, mode) {
    overrides.set(sessionId, mode)
  },
}
