// The win32 member of the Minimal anchor pair: `bash` with the persistent
// tool's schema BYTES (single `command` parameter, the exact description from
// the official `minimal` preset), executed by the gitbash `shell` service from
// this group's realm — `<bash> -c <command>`, one fresh shell per command.
// Schema identity is the anchoring variable (#11), and the model cannot see
// the executor behind a schema, so a fresh-shell backend under the persistent
// schema anchors exactly like the PTY original on Windows (the
// anchored-standard custom-bash approach, tightened to byte parity).
//
// Sandbox gating stays in the executor (gitbash-executor refuses restricted
// modes with a one-shot escalation); this tool resolves the session's CURRENT
// policy per call (dsh-tool-bash's resolve pattern, so mid-session mode
// switches take effect). Output is a plain string, like the persistent tool's
// own contract.

export const name = 'gitbash-bash-tool'

// Mirror dsh-tool-bash's dependency declaration: row application is
// CONCURRENT, so without declaring `shell` this row could apply BEFORE the
// gitbash-executor provides it — the eager guard would then throw and fail
// the whole group's mount (the "fusion unusable" regression). With the
// injection declared, cordis orders this row after the provider.
export const inject = ['tools', 'shell']

const DEFAULT_DESCRIPTION =
  'Run commands in a bash shell\n' +
  '* When invoking this tool, the contents of the "command" parameter does NOT need to be XML-escaped.\n' +
  "* You don't have access to the internet via this tool.\n" +
  '* You do have access to a mirror of common linux and python packages via apt and pip.\n' +
  '* State is persistent across command calls and discussions with the user.\n' +
  "* To inspect a particular line range of a file, e.g. lines 10-25, try 'sed -n 10,25p /path/to/the/file'.\n" +
  '* Please avoid commands that may produce a very large amount of output.\n' +
  "* Please run long lived commands in the background, e.g. 'sleep 10 &' or start a server in the background."

// Byte-parity with the wire schema dsh-tool-bash-persistent registers
// (verified against an official-minimal session's request/header snapshot).
const PARAMETERS = {
  type: 'object',
  properties: {
    command: {
      type: 'string',
      description: 'The bash command to run. Relative path is preferred in the command.',
    },
  },
  required: ['command'],
}

// The executor's run() returns STREAM objects ({text, truncated, spillPath?})
// for stdout/stderr — the dsh-bash-local shape the tool canonicalizes. Unwrap
// defensively: a plain string also works (older fakes, future shapes).
function streamText(stream) {
  if (typeof stream === 'string') return stream
  return stream?.text ?? ''
}

function resultText(outcome) {
  const parts = []
  const stdout = streamText(outcome.stdout)
  const stderr = streamText(outcome.stderr)
  if (stdout) parts.push(stdout)
  if (stderr) parts.push(stderr)
  if (outcome.truncated || outcome.stdout?.truncated || outcome.stderr?.truncated) parts.push('<response clipped>')
  let text = parts.join('\n')
  if (outcome.exitCode !== 0) text += (text.length > 0 ? '\n' : '') + `exit code: ${outcome.exitCode ?? 'unknown'}`
  if (text.length === 0) text = `exit code: ${outcome.exitCode ?? 0} (no output)`
  return text
}

export function apply(ctx, config = {}) {
  const shell = ctx.shell ?? ctx.get?.('shell')
  if (shell === undefined || typeof shell.run !== 'function') {
    throw new Error('gitbash-bash-tool: no shell service in this realm — mount inside the gitbash-shell group')
  }
  const description = config.description ?? DEFAULT_DESCRIPTION

  ctx.tools.register({
    name: 'bash',
    description,
    parameters: PARAMETERS,
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args = {}, exec = {}) {
      if (typeof args.command !== 'string' || args.command.trim().length === 0) {
        throw new Error('command must be a non-empty string')
      }
      // Per-call sandbox resolution, mirroring dsh-tool-bash: the policy
      // service resolves the session's CURRENT mode, so a mid-session switch
      // to danger-full-access takes effect immediately. The executor's gate
      // reads spec.sandboxPolicy.mode.
      const policy = typeof ctx.get === 'function' ? ctx.get('sandboxPolicy') : undefined
      const resolved = policy?.resolve?.(exec.agent === undefined ? {} : { session: exec.agent.session })
      // The session workspace, NOT process.cwd() — the backend process lives
      // in the DSH checkout, and a pwd that contradicts the session cwd once
      // cost the model a dozen steps of confusion about where it was.
      const session = exec.agent?.session
      const workdir = session?.header?.cwd ?? session?.cwd
      const spec = { command: args.command }
      if (workdir !== undefined) spec.workdir = workdir
      if (resolved !== undefined) spec.sandboxPolicy = resolved
      const outcome = await shell.run(spec)
      return resultText(outcome)
    },
    presentCall: (args) => ({
      card: 'terminal',
      title: args.command,
    }),
  })
}
