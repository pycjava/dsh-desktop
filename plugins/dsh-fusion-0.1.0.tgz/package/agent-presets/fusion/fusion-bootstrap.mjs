// The fusion behavior bootstrap. THIS MODULE OWNS EVERY ORDER-SENSITIVE
// LISTENER — the ecosystem's hard-won lesson: loader row application is
// concurrent, so listener order is only guaranteed by all three of
// (1) this row first in agent.cordis.yml, (2) `inject = []`, (3) `{ prepend: true }`
// on listeners that must be outermost. Never split these listeners across modules.
//
// Phases: 02 epoch promotion + first-round anchoring; 03 injection stripping +
// plugin-note deferral + progressive unlock; 05 task routing (band personas +
// band cores) and near-field guidance for weak sessions — all routing effects
// are POST-PROMOTION only. Request #1 is the anchor round: by default a
// synthetic identity question ("whoami") on an EMPTY tool surface with the
// persona section as the entire prompt (official Minimal's complete prompt) —
// the model's self-introduction reply is the promotion signal and anchors the
// trajectory we-style (A/B: we×36 / me×0 over 18 tool steps, vs schema-pair
// coin-flips). `anchorMode: 'pair'` swaps in the zero-extra-call Minimal pair
// (persistent-schema `bash` + `str_replace_editor`) on the real task instead
// (anchored-standard #11).

import * as core from './fusion-core.mjs'
import { createEpochPromotion, PROMOTE_EVENT_SETS } from './epoch-promotion.mjs'
import { routingState } from './routing-state.mjs'

export const name = 'fusion-bootstrap'

export const inject = []

export function apply(ctx, config = {}) {
  // Anchor mode: 'whoami' (default) seeds a synthetic identity round ahead of
  // the user's first real message — one model call buys a first durable
  // assistant message that is a self-written collaborator identity, which held
  // we-style with ZERO first-person through 18 tool-carrying steps in the A/B
  // (session 9154), while schema-pair anchoring on the real task coin-flipped
  // (a104 we / 5ba1 clipped-we / 6501+2208 me). 'pair' keeps the zero-extra-
  // call Minimal pair on the real task.
  const anchorMode = config.anchorMode === 'pair' ? 'pair' : 'whoami'
  const anchorText =
    typeof config.anchorText === 'string' && config.anchorText.length > 0 ? config.anchorText : core.WHOAMI_ANCHOR_TEXT
  // Subagent anchoring (default on): delegated agent sessions take the same
  // anchor turn — one extra model call per subagent buys a we-style child
  // whose REPORT (the part the parent absorbs back into its own context) also
  // reads anchored. Set false to restore the old behavior (subagents start
  // pre-promoted on the full catalog).
  const anchorSubagents = config.anchorSubagents !== false
  let promoteEvents = PROMOTE_EVENT_SETS[config.promoteOn] ?? PROMOTE_EVENT_SETS.either
  if (anchorMode === 'whoami' && !promoteEvents.includes('assistant/message')) {
    // A 0-tool anchor round can never produce tool/call — promotion would stall
    // and the task turn would inherit the empty catalog. Coerce, warn once.
    promoteEvents = PROMOTE_EVENT_SETS.either
    ctx.logger?.warn('[fusion] anchorMode whoami requires an assistant/message promotion signal; promoteOn coerced to either')
  }
  const promotion = createEpochPromotion(promoteEvents, { prePromoteSubagents: !anchorSubagents })

  const bootstrapTools = config.bootstrapTools ?? core.DEFAULT_BOOTSTRAP_TOOLS
  const residentTools = config.residentTools ?? core.DEFAULT_RESIDENT_TOOLS
  const shellPriority = config.shellPriority ?? core.DEFAULT_SHELL_PRIORITY
  const compactionTools = config.compactionTools ?? core.DEFAULT_COMPACTION_TOOLS
  const discoveryTools = config.discoveryTools ?? core.DEFAULT_DISCOVERY_TOOLS
  const suppressedSources = new Set(config.suppressedContextSources ?? core.DEFAULT_SUPPRESSED_SOURCES)
  const routingEnabled = config.routing !== false
  const nearGuidance = config.nearGuidance !== false

  let warnedUnusable = false
  let warnedDrift = false

  const resolveBand = (session) => {
    if (!routingEnabled) return 'weak'
    const override = routingState.getOverride(session.id)
    return core.bandOf(override !== undefined ? override : core.sessionMode(session))
  }

  // Whoami anchor injection: when the user's FIRST real message lands in the
  // inbox (agent-scoped `agent/inbox/inserted` fires after the host's splice
  // has fully committed — the safe window), prepend the synthetic identity
  // question ahead of it in next-turn. dsh claims exactly one next-turn
  // message per turn, so turn 1 = the anchor alone on an empty tool surface;
  // the real message waits for turn 2, by which time the intro reply has
  // promoted the session. Fresh-session check via durable events makes
  // re-injection impossible (inbox replay fires no `inserted` notifications).
  // Plugin-sourced inserts (the approval note, our own anchor) never trigger.
  if (anchorMode === 'whoami') {
    ctx.on('agent/inbox/inserted', ({ agent, message } = {}) => {
      try {
        if (message?.source?.kind === 'plugin') return
        const session = agent?.session ?? agent
        if (session === undefined || agent?.inbox?.prepend === undefined) return
        if (!anchorSubagents && (session.header?.delegationDepth ?? 0) > 0) return
        if ((session.events ?? []).some((event) => event.type === 'user/message')) return
        agent.inbox.prepend('next-turn', {
          id: crypto.randomUUID(),
          role: 'user',
          content: [{ type: 'text', text: anchorText }],
          source: { kind: 'plugin', plugin: 'fusion', form: 'whoami-anchor', summary: 'whoami anchor turn' },
        })
      } catch (error) {
        // An anchor-injection bug must never block the user's message.
        ctx.logger?.warn(`[fusion] whoami anchor injection failed: ${error?.message ?? error}`)
      }
    })
  }

  ctx.on('session/event', (session, event) => {
    promotion.observe(session, event)

    if (!nearGuidance || !routingEnabled) return
    if (event.type !== 'user/message') return
    const data = event.data ?? event
    const source = data.source ?? event.source
    if (source?.kind !== 'user') return
    // Delegated tasks arrive pre-framed by the parent — guidance noise has no
    // place in a subagent's round.
    if ((session.header?.delegationDepth ?? 0) > 0) return
    if (resolveBand(session) !== 'weak') return
    const agent = routingState.agentFor(session.id)
    if (agent?.inbox?.append === undefined) return
    // Post-promotion only: round 1 must carry nothing but the user's own words.
    if (!promotion.status(agent).promoted) return
    const text = typeof data.content === 'string' ? data.content : core.extractUserText({ events: [event] })
    agent.inbox.append('next-step', {
      id: `${session.id}-fusion-guide`,
      role: 'user',
      content: [{ type: 'text', text: core.guideFor(text) }],
      source: { kind: 'plugin', plugin: 'fusion', form: 'guidance', summary: 'near-field weak-session guidance' },
    })
  })

  // First-round message hygiene. MUST be { prepend: true }: the host
  // composition registers its own agent-instructions / tool-skill pre-step
  // listeners at startup, and only an outermost transform can remove what they
  // inject. Two pre-promotion transforms share one listener:
  //   (a) suppressed-source stripping (agent-instructions / skill-catalog);
  //   (b) plugin-note DEFERRAL — plugin-injected user messages (e.g. the
  //       user-approval policy-change notice) are held out of round 1 and
  //       re-delivered to next-step at the first post-promotion step. Left in,
  //       they LEAD the anchor trajectory: session 6501's model read the note
  //       as "the ask" and opened in "Let me" style. Round 1 carries nothing
  //       but the user's own words; the note's information is not lost.
  // User-invoked skills (source.kind 'skill-invocation') are real content and
  // are never held.
  const holdPluginNotes = config.deferPluginNotes !== false
  if (suppressedSources.size > 0 || holdPluginNotes) {
    const heldNotes = new Map() // session.id -> [message]
    ctx.on(
      'agent/pre-step',
      async ({ agent }, next) => {
        const decision = await next()
        if (decision.kind === 'reject') return decision
        const session = agent?.session ?? agent
        if (promotion.status(agent).promoted) {
          const held = heldNotes.get(session?.id)
          if (held !== undefined && agent?.inbox?.append !== undefined) {
            heldNotes.delete(session.id)
            for (const message of held) agent.inbox.append('next-step', message)
          }
          return decision
        }
        let messages = decision.messages
        if (suppressedSources.size > 0) {
          messages = messages.filter((message) => {
            const kind = message?.source?.kind
            return typeof kind !== 'string' || !suppressedSources.has(kind)
          })
        }
        if (holdPluginNotes) {
          const deliver = []
          const hold = []
          for (const message of messages) {
            // Our own whoami anchor is a plugin message the anchor round MUST
            // deliver — only third-party plugin notes get deferred.
            const source = message?.source
            const isHeldPlugin = source?.kind === 'plugin' && source?.plugin !== 'fusion'
            ;(isHeldPlugin ? hold : deliver).push(message)
          }
          if (hold.length > 0 && typeof session?.id === 'string') {
            const queue = heldNotes.get(session.id) ?? []
            queue.push(...hold)
            heldNotes.set(session.id, queue)
            messages = deliver
          }
        }
        return messages === decision.messages ? decision : { ...decision, messages }
      },
      { prepend: true },
    )
  }

  ctx.on('system-prompt/assemble', async (_assembly, context, next) => {
    const assembled = await next()
    try {
      const agentValue = context?.agent
      if (agentValue === undefined) return assembled
      const session = agentValue.session ?? {}
      const isSubagent = (session.header?.delegationDepth ?? 0) > 0
      // Subagent sessions are none of our business UNLESS subagent anchoring
      // is on — then they follow the same anchor/promotion flow, with one
      // carve-out below: their persona is never swapped.
      if (isSubagent && !anchorSubagents) return assembled
      if (!isSubagent) routingState.cacheAgent(agentValue)

      const status = promotion.status(agentValue)
      const band = resolveBand(session)

      if (status.promoted) {
        // Routing shapes the promoted round through the band's core tools and
        // a band persona IN THE PERSONA SLOT — the prompt stays persona-sized
        // forever (the anchored reference keeps its complete prompt all
        // session; restoring the Standard prompt measurably re-socializes the
        // model into "Let me" style).
        const bandCore = routingEnabled ? core.coreFor(band) : null
        const unlocked = core.unlockedFor(session)
        const keep = core.promotedKeepSet(bootstrapTools, discoveryTools, bandCore ?? [], unlocked, residentTools)
        const catalogNames = (assembled.tools ?? []).map((tool) => tool.name)
        if (!core.keepSetIsUsable(keep, catalogNames)) return assembled
        if (isSubagent) {
          // Same catalog discipline as the main session, but the persona
          // section keeps the child's OWN text — a subagent persona may be its
          // one contract (dsh-subagent's per-child persona option), and
          // personaSwap would clobber it.
          return { ...assembled, contexts: [], tools: (assembled.tools ?? []).filter((tool) => keep.has(tool.name)) }
        }
        const personaText =
          routingEnabled && band !== undefined ? core.personaFor(band, agentValue.options?.model) : undefined
        const sections = core.personaSwap(assembled.sections, personaText) ?? assembled.sections
        return { ...assembled, sections, contexts: [], tools: (assembled.tools ?? []).filter((tool) => keep.has(tool.name)) }
      }

      // Whoami mode, first request ever (no compaction boundary): the identity
      // anchor round — ZERO tools, persona-only prompt, no contexts. The
      // synthetic question is the only content; the model's self-introduction
      // reply becomes the first durable assistant message AND the promotion
      // signal. Post-compaction pre-promotion does NOT come back here (the
      // model is mid-task) — it falls through to the pair + compactionTools
      // workset below.
      if (anchorMode === 'whoami' && status.boundary < 0) {
        const anchorPrompt = core.anchorSections(assembled.sections)
        return anchorPrompt === null
          ? { ...assembled, contexts: [], tools: [] }
          : { ...assembled, sections: anchorPrompt, contexts: [], tools: [] }
      }

      // Pre-promotion = the anchored Minimal assembly: exactly one shell
      // (priority order, persistent schema) + str_replace_editor, and the
      // persona section as the entire system prompt — no identity, no tool
      // guidance, no band cores, no guidance messages. Standard-like
      // keep-sets do not anchor (#11); this round is not negotiable.
      const catalogNames = (assembled.tools ?? []).map((tool) => tool.name)
      const keep = core.pickBootstrapSet(catalogNames, bootstrapTools, shellPriority)
      if (status.boundary >= 0) for (const toolName of compactionTools) keep.add(toolName)

      // A missing shell is platform-normal; a missing editor is the rc.5/rc.6
      // name drift that once silently degraded round 1 to bash-only — warn.
      const missing = core.missingAnchorTools(catalogNames, bootstrapTools, shellPriority)
      if (missing.length > 0 && !warnedDrift) {
        warnedDrift = true
        ctx.logger?.warn(`[fusion] anchor-pair tool(s) absent from catalog: ${missing.join(', ')} — round 1 will lack them`)
      }

      if (!core.keepSetIsUsable(keep, catalogNames)) {
        if (!warnedUnusable) {
          warnedUnusable = true
          ctx.logger?.warn(`[fusion] bootstrap tools not present in catalog; passing full catalog through (no anchoring this session)`)
        }
        return assembled
      }
      // The anchor round's PROMPT is Minimal's complete prompt: the persona
      // section alone (46 configured bytes on the default row), no identity,
      // no tool guidance, no context sections. The persona row deliberately
      // omits `complete: true` — that would host-lock sections for the whole
      // session and kill the post-promotion router persona — so the pinning
      // happens here, pre-promotion only.
      const anchorPrompt = core.anchorSections(assembled.sections)
      if (anchorPrompt === null) return { ...assembled, tools: (assembled.tools ?? []).filter((tool) => keep.has(tool.name)) }
      return {
        ...assembled,
        sections: anchorPrompt,
        contexts: [],
        tools: (assembled.tools ?? []).filter((tool) => keep.has(tool.name)),
      }
    } catch (error) {
      // A filter bug must never brick the session.
      ctx.logger?.warn(`[fusion] catalog filter failed; passing unfiltered assembly through: ${error?.message ?? error}`)
      return assembled
    }
  })
}
