# dsh-fusion

> Experimental DeepSeek Harness agent preset: first-round anchored routing, epoch-aware promotion, progressive tool unlock, win32 Git Bash executor, and optional warmup replay.

[中文文档](README.zh-CN.md)

Task-aware anchored preset for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (DSH): first-round task routing, epoch-aware promotion, progressive tool unlock, a win32 Git Bash executor, and an optional warmup replay — fused from the best ideas of five ecosystem projects (`dsh-anchored-standard`, `dsh-router-standard`, `dsh-gitbash-preset`, `myDshPresets`, `dsh-routing-suite`).

**Status: M0–M3 implemented.** Design/research docs live in this repo (`PLUGIN-SYNTHESIS.md` et al.); the spec and ticket board are under `.scratch/dsh-fusion/`.

Targets DeepSeek Harness **0.1.0-rc.6** (developer preview — upstream breaking changes are expected).

## What it does

1. **First-round anchoring (whoami, default)** — when the user's first real message lands, a synthetic identity question (`你是谁`, configurable) is prepended ahead of it in the inbox queue; dsh consumes one next-turn message per turn, so request #1 is the identity question alone on an **empty tool surface** with the persona section (`You are a helpful software engineer assistant.`) as the entire system prompt — zero injections of any kind: runtime-context snapshots suppressed session-wide, AGENTS.md/skill-catalog context stripped, plugin notes (e.g. the user-approval policy-change notice) deferred to the first post-promotion step. The model's self-introduction reply is the first durable assistant message AND the promotion signal — a self-written collaborator identity that anchors the trajectory we-style. A/B on the same task/model: whoami held we-style with zero first-person markers across 18 tool-carrying steps and completed in 18 steps; schema-pair anchoring coin-flipped (one run: 62 first-person markers over 30 steps, interrupted). `anchorMode: 'pair'` swaps in the zero-extra-call recipe instead: the real task + persistent-schema `bash` + `str_replace_editor` (the anchored-standard #11 Minimal pair — byte-identical on every platform, Git-Bash-backed `bash` on win32).
2. **Post-promotion task routing** — the first real user message is classified (bilingual keyword rules, zero model calls) into `spec` (read-first), `react` (write-first), or `weak`; the band's core tools join the catalog at the first promoted request (#2 onward), and the band persona replaces the persona section's text — every band persona opens with the exact Minimal sentence (the system prompt's first bytes never change across the session), the tail is a we-voice identity statement with no "state your choice" meta (such instructions got echoed verbatim and immediately re-framed the model into "Let me …"), and the prompt stays persona-sized for the whole session (the full Standard prompt never returns: restoring it was measured to flip the anchored "We need…" style back to "Let me" immediately). Near-field guidance for weak sessions also waits for promotion.
3. **Epoch-aware promotion** — the first durable `tool/call` or `assistant/message` promotes the session (one catalog change). `compaction/end` is an epoch boundary: after a fold the session returns to the controlled phase until a new signal. All phase state derives from durable events — resume/reload safe.
4. **Progressive unlock** — promoted catalog is a minimal resident set + `dev_tool_search`; the heavy Standard tools are one search away, and unlock calls are replayed from the durable log.
5. **win32 Git Bash backend** — `bash` works on Windows through Git for Windows (`<bash> -c <command>`, fresh shell per command, sandbox-gated), registered under the persistent tool's schema bytes so the anchor identity holds.
6. **Optional warmup replay (off by default)** — a synthetic warmup round whose model call is short-circuited by a replayed chunk stream; saves one model call per fresh session.
7. **Subagent anchoring** (default on) — delegated agent sessions take the same whoami anchor turn: the task prompt (a user-kind inbox message) gets the identity question prepended ahead of it, turn 1 introduces itself on an empty tool surface, and the reply promotes the child to the resident catalog. The child's persona is never swapped (a per-child persona is its one contract — `dsh-subagent`'s persona option), near-field guidance never fires inside children, and a narrowed child catalog (toolFilter-style) fails soft to passthrough. One extra model call per subagent; `anchorSubagents: false` restores children starting pre-promoted on the full catalog.

8. **Self-optimization tools** (post-promotion only) — `dev_router_status`, `dev_router_mode` (explicit override; process-local), `dev_mode_subagent` (isolated single-task call under another persona, no mid-session persona flips).

## Install (requires a DSH installation)

```powershell
# from a clone of this repository:
.\install.ps1
# …or directly:
dsh plugin --profile web add <path-to-this-repo>
```

Restart DSH fully, create a **new** session, select **Fusion (experimental)**. Do not switch presets mid-session.

If DSH fails to start after a partial install: `node scripts\fix-patch.mjs %USERPROFILE%\.dsh\profiles\web\cordis.patch.yml`.

## Configuration switches (`agent-presets/fusion/agent.cordis.yml`)

| Row | Switch | Default | Effect |
|---|---|---|---|
| fusion-bootstrap | `anchorMode` | `whoami` | Anchor round: synthetic identity turn on an empty tool surface (`pair` = Minimal tool pair on the real task, zero extra calls) |
| | `anchorText` | `你是谁` | The identity question's text (whoami mode only) |
| | `anchorSubagents` | `true` | Delegated agent sessions take the same anchor turn; post-promotion children keep the resident catalog but never a persona swap (a child persona may be its one contract). One extra model call per subagent |
| | `promoteOn` | `either` | Promotion signal: `tool-call` \| `assistant-message` \| `either` (whoami mode coerces tool-call to either — a 0-tool round can never produce tool/call) |
| | `bootstrapTools` | `[bash, pwsh, str_replace_editor]` | Minimal pair members — persistent-schema shell by `shellPriority` + `str_replace_editor`; `pwsh` never reaches the anchor round but stays resident post-promotion on win32 |
| | `residentTools` | `[modlens_read_image]` | Always-on post-promotion tools that are not part of the Minimal anchor pair; they never appear in the anchor round |
| | `shellPriority` | `[bash, pwsh]` | Which single shell wins the anchor round |
| | `suppressedContextSources` | `[agent-instructions, skill-catalog]` | Pre-promotion injection stripping (`[]` disables) |
| | `deferPluginNotes` | `true` | Pre-promotion deferral of plugin-injected user messages (e.g. the user-approval policy note); re-delivered at the first post-promotion step |
| | `discoveryTools` | `[dev_tool_search]` | Post-promotion resident discovery tools |
| | `compactionTools` | see yml | Post-compaction workset |
| | `routing` / `nearGuidance` | `true` | Post-promotion band personas/cores / weak-session near-field guidance |
| warmup-replay | `enabled` | `false` | Warmup round + first-call replay veto |
| | `message` / `replayFile` | see yml | Warmup prompt / replay data (bundled file is a SYNTHETIC placeholder — record a real session for production) |
| gitbash-executor | `shellPath` | auto-detect | Explicit Git Bash path (else `GIT_BASH` → install dirs → PATH) |
| | `timeoutMs` / `maxOutputBytes` / `graceMs` | `120000` / `64000` / `3000` | Command timeouts and output window |

Host installer (`dsh` patch config on the bundle row): `dshHome`, `presetId`, `force` (overwrite stale preset files), `presetSourceDir` (test seam).

## Compatibility

| DSH | Status |
|---|---|
| 0.1.0-rc.6 | Target. Baseline composition snapshot taken from the rc.6 Standard preset. |
| 0.1.0-rc.5 | Mostly compatible; **request-budget caveat**: an rc.6 prebuilt profile can override a proposed first-round maxTokens cap (no-op) — dsh-fusion ships no cap by default, so unaffected. Verify `request/header` after any upgrade. |

Known upstream-fragile points (checked on every rc bump): waterfall listener ordering (`prepend` contract), `agent/request` maxTokens semantics, patch dialect.

## Security notes

- The Git Bash executor **never bypasses the sandbox**: it only runs under `danger-full-access`; restricted modes get a one-shot escalation message (with justification) for the user to approve or reject.
- `danger-full-access` escalation means that single command runs outside the sandbox — read the justification before approving.
- This preset's filesystem rows use the bare local FS provider inside the preset's realm (same as upstream Standard); the host sandbox FS is shadowed for sessions on this preset.
- No runtime code-execution features (no staging/`new Function` tooling), no network calls, no telemetry; only `node:` builtins are imported.

## Development

```
npm run check   # syntax gate on every plugin file (8→23 files)
npm test        # unit + fake-ctx seam tests (no DSH needed)
```

- Research & design: `RESEARCH.md`, `TECH-BEHAVIOR.md`, `TECH-INFRA.md`, `PLUGIN-SYNTHESIS.md`
- Agent conventions: `AGENTS.md`, `docs/agents/`

## Credits

- The **whoami anchor** (`anchorMode: 'whoami'`, default) is adapted from the `whoami-standard/` variant of [xiaobright/dsh-anchored-standard](https://github.com/xiaobright/dsh-anchored-standard) — its `whoami-turn` mechanism and the `你是谁` anchor text. Special thanks to **xiaobright** for this idea.
- dsh-fusion also fuses ideas from [yjh051108/dsh-router-standard](https://github.com/yjh051108/dsh-router-standard) (bilingual task-band router and personas), [liceses/dsh-gitbash-preset](https://github.com/liceses/dsh-gitbash-preset) (win32 Git Bash executor and host-installer bridge), [0liveiraaa/myDshPresets](https://github.com/0liveiraaa/myDshPresets) (warmup replay), and [yjh051108/dsh-routing-suite](https://github.com/yjh051108/dsh-routing-suite) (packaging and engineering discipline).

## License

MIT. The bundled `agent.cordis.yml` derives from the DeepSeek Harness Standard preset composition (rc.6 snapshot), via [yjh051108/dsh-router-standard](https://github.com/yjh051108/dsh-router-standard) — see `NOTICE` and `LICENSE.deepseek-harness`.
